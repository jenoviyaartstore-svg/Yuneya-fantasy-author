export default function Home() {
  return (
    <main className="bg-black text-white min-h-screen flex flex-col items-center justify-center">
      <h1 className="text-5xl font-bold mb-6">✨ Yuneya Fantasy World ✨</h1>
      <p className="text-xl max-w-2xl text-center">
        Добро пожаловать в волшебный мир моих книг.  
        Подпишитесь, чтобы получать новости, или выберите книгу, чтобы начать путешествие.
      </p>
    </main>
  );
}