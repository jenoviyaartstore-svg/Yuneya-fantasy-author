# 🌙 Yuneya Fantasy Author Website

## 🚀 Frontend (Next.js)
- Команда запуска:
```bash
cd frontend
npm install
npm run dev
```

## ⚙️ Backend (NestJS)
- Команда запуска:
```bash
cd backend
npm install
npm run start:dev
```

## 🌍 Deploy
- **Frontend** → Netlify (папка `frontend/`)
- **Backend** → Render (папка `backend/`)
